//
//  EditManager.h
//  HanCamera
//
//  Created by 韩畅 on 14/11/10.
//  Copyright (c) 2014年 韩畅. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface EditManager : NSObject
@property UIImage *imageToEdit;
@end
