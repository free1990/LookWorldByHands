//
//  EditManager.m
//  HanCamera
//
//  Created by 韩畅 on 14/11/10.
//  Copyright (c) 2014年 韩畅. All rights reserved.
//

#import "EditManager.h"

@implementation EditManager
@synthesize imageToEdit;
@end
